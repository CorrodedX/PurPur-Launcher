export {}

declare global {
  interface Window {
    require: NodeRequire
  }
}
