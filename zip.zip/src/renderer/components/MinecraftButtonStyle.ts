export enum MinecraftButtonStyle {
  Confirm,
  Warn
}
